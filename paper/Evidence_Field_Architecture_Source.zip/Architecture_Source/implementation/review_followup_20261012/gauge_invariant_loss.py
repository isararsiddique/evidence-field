"""Candidate class-relative evidence loss. Frozen trainers are not modified.

Tensor contract: batch, class, spatial axes. Class centering is pointwise.
The gauge-common field is retained for score accounting, not optimized as
discriminative evidence. These functions do not claim diagnostic gains.
"""
import numpy as np

def numpy_center(fields):
    value=np.asarray(fields,dtype=np.float64)
    if value.ndim<3 or value.shape[1]<2 or not np.isfinite(value).all():
        raise ValueError('Finite batch/class/spatial fields with at least two classes required')
    return value-value.mean(axis=1,keepdims=True)

def numpy_distance(first,aligned_second,epsilon=1e-12):
    if np.shape(first)!=np.shape(aligned_second) or not epsilon>0:
        raise ValueError('Matching aligned fields and positive epsilon required')
    a,b=numpy_center(first),numpy_center(aligned_second)
    axes=tuple(range(2,a.ndim))
    per_class=np.abs(a-b).sum(axis=axes)/(np.abs(a).sum(axis=axes)+np.abs(b).sum(axis=axes)+epsilon)
    return float(per_class.mean()),per_class

def torch_distance(first,aligned_second,epsilon=1e-12):
    """Differentiable first/mixed-derivative path; imports Torch only on demand."""
    if first.shape!=aligned_second.shape or first.ndim<3 or first.shape[1]<2 or not epsilon>0:
        raise ValueError('Matching batch/class/spatial tensors and positive epsilon required')
    a=first.double();b=aligned_second.double()
    a=a-a.mean(dim=1,keepdim=True);b=b-b.mean(dim=1,keepdim=True)
    axes=tuple(range(2,a.ndim))
    distances=(a-b).abs().sum(axes)/(a.abs().sum(axes)+b.abs().sum(axes)+epsilon)
    return distances.mean()

def centered_l1_gradient(first,aligned_second,epsilon=1e-12):
    """Independent NumPy subgradient, with sign(0)=0, for checking Torch."""
    a,b=numpy_center(first),numpy_center(aligned_second)
    axes=tuple(range(2,a.ndim));keep=dict(axis=axes,keepdims=True)
    num=np.abs(a-b).sum(**keep);den=np.abs(a).sum(**keep)+np.abs(b).sum(**keep)+epsilon
    ga=(np.sign(a-b)*den-num*np.sign(a))/(den*den)
    gb=(-np.sign(a-b)*den-num*np.sign(b))/(den*den)
    scale=a.shape[0]*a.shape[1]
    return (ga-ga.mean(1,keepdims=True))/scale,(gb-gb.mean(1,keepdims=True))/scale
