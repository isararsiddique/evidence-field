"""Optional direct rectangular contractions for the unchanged EF 0.4 field.

Import the intended evidence_field package before this module. This file changes
execution only: response, reference, basis, normalization, score and cover math
remain the registered math. It allocates no pixel-by-support mask and uses no
prefix subtraction. Region contractions and their adjoints operate in FP64.
"""
import numpy as np
import torch

from evidence_field.stable_program import StableRegistryFieldEncoder
from evidence_field.vector_program import VectorStableProgram, VectorOpticalProgram


class _RectangularContractions(torch.autograd.Function):
    """Compute response/basis products only inside the requested rectangles.

    A custom adjoint avoids creating one full-image SliceBackward result per
    support. Saved tensors are the shared response and basis, not region copies.
    The backward is expressed in Torch operations and supports higher derivatives;
    higher-derivative performance is outside the present CPU cost measurement.
    """
    @staticmethod
    def forward(ctx, response, basis, supports):
        if response.dtype != torch.float64 or basis.dtype != torch.float64:
            raise TypeError("Direct support contractions require FP64 operands")
        ctx.save_for_backward(response, basis)
        ctx.supports = supports
        result = []
        for support in supports:
            a = response[(slice(None), slice(None), *support)].flatten(2)
            b = basis[(slice(None), *support)].flatten(1)
            result.append(a @ b.T)
        return torch.stack(result, 1)

    @staticmethod
    def backward(ctx, grad_output):
        response, basis = ctx.saved_tensors
        grad_response = torch.zeros_like(response) if ctx.needs_input_grad[0] else None
        grad_basis = torch.zeros_like(basis) if ctx.needs_input_grad[1] else None
        for v, support in enumerate(ctx.supports):
            response_index = (slice(None), slice(None), *support)
            basis_index = (slice(None), *support)
            a = response[response_index].flatten(2)
            b = basis[basis_index].flatten(1)
            grad = grad_output[:, v]
            if grad_response is not None:
                grad_response[response_index] += (grad @ b).reshape(response[response_index].shape)
            if grad_basis is not None:
                total = grad.flatten(0, 1).T @ a.flatten(0, 1)
                grad_basis[basis_index] += total.reshape(basis[basis_index].shape)
        return grad_response, grad_basis, None


class DirectSupportRegistryFieldEncoder(StableRegistryFieldEncoder):
    """DenseRegistryFieldEncoder descriptors without its dense support mask."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._support_cache = {}

    def supports(self, shape, geometry):
        bounds = np.asarray(geometry['bounds'])
        key = (tuple(shape), bounds.tobytes())
        if key not in self._support_cache:
            if bounds.shape[1:] != (len(shape), 2):
                raise ValueError('Bounds dimensionality does not match field')
            if np.any(bounds[:, :, 0] < 0) or np.any(bounds[:, :, 1] > np.asarray(shape)) or np.any(bounds[:, :, 1] <= bounds[:, :, 0]):
                raise ValueError('Invalid rectangular support')
            self._support_cache[key] = tuple(tuple(slice(int(lo), int(hi)) for lo, hi in row) for row in bounds)
        return self._support_cache[key]

    def forward(self, q, g):
        q = q.double(); shape = q.shape[2:]; dim = len(shape); device = q.device; dtype = q.dtype
        axes = [(torch.arange(s, device=device, dtype=dtype)+.5)/s*2-1 for s in shape]
        coord = list(torch.meshgrid(*axes, indexing='ij'))
        if dim == 2: coord = [torch.zeros_like(coord[0])] + coord
        u = torch.stack(coord); phase = torch.einsum('cp,lc->lp', u.flatten(1), self.wavevectors())
        harmonic = torch.stack([phase.cos(), phase.sin()], 1).reshape(2*self.frequencies, *shape)
        basis = torch.cat([torch.stack([torch.ones_like(coord[0]), *coord,
            *[coord[i]*coord[j] for i in range(3) for j in range(i, 3)]]), harmonic])
        response = self.response(q); bounds = torch.as_tensor(g['bounds'], device=device)
        sums = _RectangularContractions.apply(response, basis, self.supports(shape, g))
        self.last_sums = sums if not self.training else None
        volume = (bounds[:, :, 1]-bounds[:, :, 0]).prod(1).to(dtype)
        sizes = torch.tensor(shape, device=device, dtype=dtype)
        midpoint = (bounds[:, :, 1]+bounds[:, :, 0]).to(dtype)/sizes-1
        halfwidth = (bounds[:, :, 1]-bounds[:, :, 0]).to(dtype)/sizes
        if dim == 2:
            midpoint = torch.cat([torch.zeros_like(midpoint[:, :1]), midpoint], 1)
            halfwidth = torch.cat([torch.ones_like(halfwidth[:, :1]), halfwidth], 1)
        weight = sums[..., 0].clamp(min=1e-6); centre = sums[..., 1:4]/weight[..., None]
        cov = torch.stack([(sums[..., 4+k]/weight-centre[..., i]*centre[..., j])/
            (halfwidth[None, :, None, i]*halfwidth[None, :, None, j])
            for k, (i, j) in enumerate(((i, j) for i in range(3) for j in range(i, 3)))], -1)
        valid = sums[..., 0] > 1e-6
        local = torch.where(valid[..., None], (centre-midpoint[None, :, None])/halfwidth[None, :, None], 0.)
        cov = torch.where(valid[..., None], cov, 0.)
        angle = midpoint @ self.wavevectors().T; c = angle.cos()[None, :, None]; s = angle.sin()[None, :, None]
        raw = sums[..., 10:].reshape(len(q), len(bounds), self.responses_count, self.frequencies, 2)
        real = (raw[..., 0]*c+raw[..., 1]*s)/weight[..., None]
        imag = (raw[..., 1]*c-raw[..., 0]*s)/weight[..., None]
        signatures = torch.stack([real, imag], -1).flatten(3)
        return torch.cat([(sums[..., 0]/volume[None, :, None])[..., None], local, cov, signatures], -1).flatten(2)


def install_direct_support(model):
    """Opt in before creating an optimizer; preserve state and training flags.

    The model's state_dict keys, fingerprint and certificate schema are unchanged.
    An existing optimizer would still hold the previous encoder parameters, so
    callers must install first and construct their optimizer afterwards.
    """
    c = model.config
    if c.core_version != 'ef-adaptive-program/0.4':
        raise ValueError('This optional backend is restricted to EF 0.4 mathematics')
    original = model.encoder
    parameter = next(original.parameters())
    encoder = DirectSupportRegistryFieldEncoder(c.responses, c.seed, c.learned_encoder,
        c.frequencies, c.learned_frequencies, c.frequency_limit, 'response_mass')
    encoder.to(device=parameter.device, dtype=parameter.dtype)
    encoder.load_state_dict(original.state_dict(), strict=True)
    for name, parameter in encoder.named_parameters():
        parameter.requires_grad_(dict(original.named_parameters())[name].requires_grad)
    encoder.train(original.training)
    model.encoder = encoder
    return model


install_direct_support_backend = install_direct_support


class DirectSupportStableProgram(VectorStableProgram):
    def __init__(self, config):
        super().__init__(config); install_direct_support(self)


class DirectSupportOpticalProgram(VectorOpticalProgram):
    def __init__(self, config):
        super().__init__(config); install_direct_support(self)
