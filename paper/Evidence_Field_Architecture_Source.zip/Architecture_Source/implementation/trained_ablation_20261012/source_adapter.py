"""Fresh-process full-source training adapters with explicit protocol identities."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, sys

HERE = Path(__file__).resolve().parent
ROOT = Path(os.environ.get('EF_RESEARCH_ROOT', '/home/ubuntu/evidence_field_next_20261011_multi_gpu'))
APP = ROOT/'application_studies'
ARCH = APP/'architecture_revision_v05'
ENGINE = ARCH/'histology_training_extension/new_full_source'
def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as stream:
        for b in iter(lambda: stream.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()
def prepared():
    return Path(json.loads((APP/'histopathology/new_full_source_study/camelyon/input_receipt.json').read_text())['prepared_path'])


def engine(variant, family='ef', lr_multiplier=1., preprocessing='rgb'):
    sys.path.insert(0, str(ENGINE))
    spec = importlib.util.spec_from_file_location('_isolated_trained_ablation_engine', ENGINE/'train_source_fit.py')
    fit = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = fit
    spec.loader.exec_module(fit)
    r = fit.runtime()
    torch = r['torch']
    from mechanism_models import VARIANTS, build_control
    if family not in ('ef', 'cnn', 'vit') or lr_multiplier not in (.5, 1., 2., 4.):
        raise ValueError('Unregistered family/learning rate')
    if family == 'ef' and (variant not in VARIANTS or preprocessing != 'rgb'):
        raise ValueError('EF consumes RGB through its authenticated optical adapter')
    if family != 'ef' and (variant != 'paired_baseline' or preprocessing not in ('rgb', 'optical_density')):
        raise ValueError('Unregistered paired comparator')
    original_build, original_objective, original_protocol = fit.build_model, fit.objective, fit.protocol
    original_adam = torch.optim.AdamW

    class InputWrapper(torch.nn.Module):
        def __init__(self, model):
            super().__init__()
            self.model = model
        def forward(self, x):
            if preprocessing == 'optical_density':
                x = -x.clamp(1/256, 1).log()/__import__('math').log(256)
            return self.model(x)

    def build(method, classes, size, seed):
        if family == 'ef':
            return build_control(original_build('ef_two_ce', classes, size, seed), variant, ARCH)
        return InputWrapper(original_build(family, classes, size, seed))
    fit.build_model = build
    def objective(model, x, y, method, tau, rotation=0, flip=False):
        if family == 'ef':
            return original_objective(model, x, y, 'ef_two_ce', tau, rotation, flip)
        changed = r['AxialRigid'](int(rotation), bool(flip)).apply(x)
        ce = .5*(torch.nn.functional.cross_entropy(model(x), y)+
                  torch.nn.functional.cross_entropy(model(changed), y))
        return ce, {'ce': ce}
    fit.objective = objective
    def adam(params, lr, **kwargs):
        return original_adam(params, lr=lr*lr_multiplier, **kwargs)
    torch.optim.AdamW = adam  # Private fresh process; frozen source is untouched.
    method = 'ef_two_ce' if family == 'ef' else family
    def protocol():
        d = original_protocol()
        d.update(schema='full-source-trained-mechanism-and-paired-baseline/1', datasets=['camelyon'],
                 methods=[method], fits_per_dataset=3,
                 comparison={'variant': variant, 'family': family, 'preprocessing': preprocessing,
                             'learning_rate_multiplier': lr_multiplier, 'two_views_for_every_family': True,
                             'effective_batch': 64, 'epochs': 16, 'seeds': [11, 29, 47]},
                 candidate_contract={'adapter_sha256': sha(Path(__file__)),
                                     'model_helper_sha256': sha(HERE/'mechanism_models.py'),
                                     'engine_sha256': sha(ENGINE/'train_source_fit.py'),
                                     'baseline_source_lock_sha256': sha(APP/'histopathology/new_full_source_study/camelyon/source_checkpoint_lock.json'),
                                     'controls_sha256': {str(p.relative_to(ARCH)): sha(p) for p in
                                        (ARCH/'descriptor_controls/control_model.py', ARCH/'cost_backend/direct_support.py',
                                         ARCH/'gaussian_control/gaussian_model.py', ARCH/'gaussian_control/gaussian_contract.py')},
                                     'frozen_numerical_modules_changed': False},
                 objective={method: {'two_view_cross_entropy': True, 'probability_regularizer': 0, 'evidence_regularizer': 0}},
                 microbatches={'camelyon': {'EF':32,'cnn':64,'vit':64}},
                 architecture={'family':family,'variant':variant,'preprocessing':preprocessing,
                               'factory':'Isolated registered control built from authenticated from-scratch factory'},
                 augmentation='Same whole-patch D4 plus further independently sampled D4 view for every family',
                 variant_selection='Report all mechanism controls; matched two-trial family comparison uses source validation only',
                 target_gate='All registered source fits must lock before any new target inference. Targets never select trials.',
                 final_trained_outcomes=False)
        d['optimizer']['learning_rates']={family:(.003 if family=='ef' else .001)*lr_multiplier}
        return d
    fit.protocol = protocol
    return fit, method


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--variant', required=True)
    p.add_argument('--family', choices=['ef', 'cnn', 'vit'], default='ef')
    p.add_argument('--lr-multiplier', type=float, default=1.)
    p.add_argument('--preprocessing', choices=['rgb', 'optical_density'], default='rgb')
    p.add_argument('--seed', type=int, choices=[11, 29, 47], required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--execute', action='store_true')
    a = p.parse_args()
    if not a.execute:
        raise SystemExit('Explicit execution required')
    q = json.loads((HERE/'Source_Implementation_QA.json').read_text())
    if not q['passed'] or q['helper_hashes'] != {n: sha(HERE/n) for n in ('source_adapter.py', 'mechanism_models.py')}:
        raise RuntimeError('Actual source implementation QA is missing or stale')
    fit, method = engine(a.variant, a.family, a.lr_multiplier, a.preprocessing)
    fit.run_fit('camelyon', method, a.seed, prepared(), a.output, 'cuda:0', 4)
if __name__ == '__main__':
    main()
