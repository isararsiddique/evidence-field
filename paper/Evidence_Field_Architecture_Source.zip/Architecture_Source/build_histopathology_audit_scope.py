"""Select the histopathology/architecture portions of an existing audit.

This performs no training, prediction or new numerical verification. The
original combined audit remains unchanged and its hash is retained.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

C = Path(__file__).resolve().parent
ROOT = C.parents[2]
source = ROOT / "outputs/Evidence_Field_Next_Research/Verified_v04/Three_Study_Training_Check.json"
original = json.loads(source.read_text())
assert original["passed"] and original["new_optimizer_steps"] == 0
assert set(original["archive_checks"]) == {"trained_architecture", "histopathology"}
assert len(original["fit_checks"]) == 43
assert all(r["study"] in ("histopathology", "architecture") for r in original["fit_checks"])
retained_keys = ("checked_utc", "new_optimizer_steps", "gpu_or_ssh_used", "target_tuning",
                 "archive_checks", "fit_checks", "prediction_checks", "histopathology",
                 "architecture", "passed", "reproduction_script")
record = {k: original[k] for k in retained_keys}
record.update(
    scoped_utc=datetime.now(timezone.utc).isoformat(),
    scope="Histopathology and its focused trained architectural comparisons only",
    source_audit_path=str(source),
    source_audit_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    omitted_sections=["lung", "publication_status"],
    omission_reason="The revised core manuscript uses only histopathology application evidence; the original combined audit is preserved.",
    no_new_numerical_check=True,
)
dest = C / "Histopathology_Architecture_Training_Check.json"
dest.write_text(json.dumps(record, indent=2) + "\n")
print(f"Scoped {len(record['fit_checks'])} unchanged fit records; original audit retained.")
