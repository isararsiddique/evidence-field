"""Isolated EF descriptor controls; frozen numerical modules remain unchanged.

Equal registered head tensors and descriptor width do not imply equal active
trainable capacity. Moments-only removes signatures throughout fitting and replay.
"""
from dataclasses import dataclass
import sys
import numpy as np
import torch

if 'evidence_field' not in sys.modules:
    try:
        from .bootstrap import bind_frozen_source
    except ImportError:
        from bootstrap import bind_frozen_source
    bind_frozen_source()

from evidence_field.stable_program import StableProgramConfig
from evidence_field.dense_program import DenseOpticalProgram, DenseStableProgram
from evidence_field.medical_input import SPECTRAL_CONTRACT

VERSION = 'ef-descriptor-controls/0.5.0'
SCHEMA = 'ef-descriptor-control-certificate/0.5.0'
MODES = ('learned_frequency', 'fixed_frequency', 'moments_only', 'no_explicit_parent')
ALIASES = {'learned': 'learned_frequency', 'no_parent': 'no_explicit_parent'}


@dataclass
class DescriptorControlConfig(StableProgramConfig):
    responses: int = 8
    frequencies: int = 4
    calibration: str = SPECTRAL_CONTRACT
    max_order: int = 2
    descriptor_control: str = 'learned_frequency'
    descriptor_control_version: str = VERSION


def canonical_raw_wavevectors(frequencies=4, frequency_limit=8*np.pi):
    directions = np.array([[0, 1, 0], [0, 2, 0], [0, 0, 1], [1, 0, 0]], float)
    initial = np.stack([3*np.pi*directions[t % 4] / (1+t//4) for t in range(frequencies)])
    return np.arctanh(np.clip(initial/frequency_limit, -.95, .95)).astype(np.float32)


def signature_indices(config):
    per_response = 10 + 2 * config.frequencies
    field_width = config.responses * per_response
    return [block * field_width + response * per_response + component
            for block in range(3) for response in range(config.responses)
            for component in range(10, per_response)]


class _ControlMixin:
    def __init__(self, config):
        config.descriptor_control = ALIASES.get(config.descriptor_control, config.descriptor_control)
        if config.descriptor_control not in MODES or config.descriptor_control_version != VERSION:
            raise ValueError('Explicit versioned descriptor-control contract required')
        if not config.learned_encoder or config.responses != 8 or config.frequencies != 4:
            raise ValueError('The registered comparison fixes learned radial responses, R8/L4')
        config.learned_frequencies = config.descriptor_control in ('learned_frequency', 'no_explicit_parent')
        config.cross_scale = config.descriptor_control != 'no_explicit_parent'
        super().__init__(config)
        mask = torch.ones(self.width, dtype=torch.float32)
        if config.descriptor_control == 'moments_only':
            mask[signature_indices(config)] = 0
        self.register_buffer('_descriptor_mask', mask, persistent=False)

    def load_state_dict(self, state_dict, strict=True, assign=False):
        result = super().load_state_dict(state_dict, strict=strict, assign=assign)
        # A frozen learned checkpoint may be reused only as a numerical probe.
        # Fixed/moment controls always restore the source-declared fixed bank.
        if not self.config.learned_frequencies:
            with torch.no_grad():
                self.encoder.raw_wavevectors.copy_(torch.from_numpy(canonical_raw_wavevectors(
                    self.config.frequencies, self.config.frequency_limit)).to(self.encoder.raw_wavevectors))
            self.encoder.raw_wavevectors.requires_grad_(False)
        return result

    def descriptors(self, x, spacing=None):
        phi, geometry = super().descriptors(x, spacing)
        return phi * self._descriptor_mask.to(dtype=phi.dtype, device=phi.device), geometry

    def control_contract(self):
        return dict(version=VERSION, schema=SCHEMA, mode=self.config.descriptor_control,
                    descriptor_width=self.width,
                    signature_mask_indices=signature_indices(self.config) if self.config.descriptor_control == 'moments_only' else [],
                    keeps_parent_root_descriptor_contrasts=True,
                    explicit_parent_correction=self.config.cross_scale,
                    learned_radial_responses=True, learned_frequencies=self.config.learned_frequencies,
                    fixed_bank='Preserved structural_field.py canonical initial bank; raw FP32 coordinates are enforced' if not self.config.learned_frequencies else None,
                    unchanged_registered_state_tensor_keys=True,
                    comparison_scope='Nominal descriptor dimensions and head tensors matched; active capacity differs and is accounted separately')

    def certificate(self, x, spacing=None):
        record = super().certificate(x, spacing)
        record['schema'] = SCHEMA
        record['control_contract'] = self.control_contract()
        record['verification_contract'] = 'Separate control schema; externally authenticated original coefficients/configuration/model and source input; fresh no-Torch control reader'
        return record

    def records(self, x, spacing=None):
        """Batch convenience matching the logits/records interface of EF models."""
        records = [self.certificate(row[None], spacing) for row in x]
        return torch.tensor([r['logits'] for r in records], device=x.device, dtype=x.dtype), records


class DescriptorControl(_ControlMixin, DenseOpticalProgram):
    """Native RGB optical-density control."""


class CTDescriptorControl(_ControlMixin, DenseStableProgram):
    """Prepared HU volume control; same covering program and 435-wide descriptor."""
    def __init__(self, config):
        if config.calibration != 'ct_hu':
            raise ValueError('Explicit prepared CT HU contract required')
        super().__init__(config)


def build_ct_control(control, seed, responses=8, frequencies=4):
    return CTDescriptorControl(DescriptorControlConfig(classes=2, seed=seed,
        responses=responses, frequencies=frequencies, calibration='ct_hu', depth=2,
        max_order=2, descriptor_control=ALIASES.get(control, control)))


def parameter_accounting(model):
    config = model.config; k = config.classes; m = config.pair_types; d = model.width
    order_count = config.max_order - 1
    signature_width = 3 * config.responses * 2 * config.frequencies
    inactive = {}
    if config.descriptor_control == 'moments_only':
        inactive = dict(own_signature_coefficients=k * config.node_types * signature_width,
                        group_signature_coefficients=order_count * k * m * 3 * signature_width,
                        member_signature_projections=order_count * k * m * signature_width,
                        parent_signature_projections=order_count * k * m * signature_width,
                        frequency_coordinates=int(model.encoder.raw_wavevectors.numel()))
    elif config.descriptor_control == 'no_explicit_parent':
        inactive = dict(explicit_parent_affine_coefficients=order_count * k * m * d,
                        explicit_parent_projection_coefficients=order_count * k * m * (d - 1))
    elif config.descriptor_control == 'fixed_frequency':
        inactive = dict(frequency_coordinates=int(model.encoder.raw_wavevectors.numel()))
    registered = sum(p.numel() for p in model.parameters())
    return dict(registered_parameters=registered,
                requires_grad_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
                registered_head_parameters=sum(p.numel() for name, p in model.named_parameters() if not name.startswith('encoder.')),
                declared_control_inactive_coordinates=inactive,
                control_inactive_coordinate_count=sum(inactive.values()),
                nominal_remaining_coordinates_after_control=registered - sum(inactive.values()),
                interpretation='Nominal coordinate accounting, not effective rank. Requires-grad coordinates include structurally masked/disabled head coordinates. Observed nonzero gradients are sample/loss dependent. The padded 2D axis and fixed bank create further degeneracies; hard selected routes also make activity data dependent.')
