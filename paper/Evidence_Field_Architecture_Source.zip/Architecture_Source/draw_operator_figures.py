"""Technical operator diagrams at final manuscript width; no result placeholders."""
from pathlib import Path
import json,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Circle

OUT=Path(__file__).resolve().parent/'figures';OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.1,'svg.fonttype':'none','pdf.fonttype':42})
COL={'pink':'#f8dce1','blue':'#bce8f4','orange':'#ffe1b5','yellow':'#f1f0bd','green':'#c7e7cd','violet':'#dcdcf0','gray':'#f4f5f7'}
receipts=[]

def sheet(height):
 f=plt.figure(figsize=(5.5,.9*height/72));a=f.add_axes([0,0,1,1]);a.set(xlim=(0,486),ylim=(0,height));a.axis('off');a._ef_segments=[];return f,a
def box(a,x,y,w,h,label,color='blue',size=9.1):
 a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=4',edgecolor='#25364a',facecolor=COL[color],lw=1.15))
 # Measure each line independently. Large math operators have different heights;
 # a single multiline text object does not reliably keep their glyphs apart.
 ts=[a.text(x+w/2,y+h/2,s,ha='center',va='center',fontsize=size) for s in label.split('\n')]
 a.figure.canvas.draw();ren=a.figure.canvas.get_renderer()
 bounds=[t.get_window_extent(ren) for t in ts]
 gap=2*a.figure.dpi/72
 cy=a.transData.transform((x+w/2,y+h/2))[1]
 top=cy+(sum(b.height for b in bounds)+gap*(len(ts)-1))/2
 for t,b in zip(ts,bounds):
  old=a.transData.transform(t.get_position())
  delta=(x+w/2,top-b.height/2)
  desired=a.transData.transform((x+w/2,y+h/2))[0]
  shift=(desired-(b.x0+b.x1)/2,delta[1]-(b.y0+b.y1)/2)
  t.set_position(a.transData.inverted().transform(old+shift))
  t._ef_container=(x,y,w,h);top-=b.height+gap
 return ts[0]
def text(a,x,y,label,size=9.1,**kw):return a.text(x,y,label,fontsize=size,**kw)
def line(a,p,q):
 a.plot([p[0],q[0]],[p[1],q[1]],color='#25364a',lw=1.05);a._ef_segments.append((p,q))
def arrow(a,p,q):
 a.add_patch(FancyArrowPatch(p,q,arrowstyle='-|>',mutation_scale=8.5,lw=1.05,color='#25364a',shrinkA=1,shrinkB=1));a._ef_segments.append((p,q))
def route(a,points):
 for p,q in zip(points[:-2],points[1:-1]):line(a,p,q)
 arrow(a,points[-2],points[-1])
def circle(a,x,y,label):
 a.add_patch(Circle((x,y),8,fc=COL['yellow'],ec='#25364a',lw=1.1));text(a,x,y,label,10,ha='center',va='center')
def enclosure(a,x,y,w,h,label):
 a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=8',edgecolor='#5a6673',facecolor=COL['gray'],lw=1.05,zorder=0))
 text(a,x-10,y+h/2,label,9.1,rotation=90,ha='center',va='center',weight='bold')
def save(f,a,name):
 f.canvas.draw();renderer=f.canvas.get_renderer();bounds=[]
 for t in a.texts:
  b=t.get_window_extent(renderer);bounds.append((t,b))
  assert b.x0>=0 and b.y0>=0 and b.x1<=f.bbox.width and b.y1<=f.bbox.height,(name,t.get_text(),'outside canvas')
  if hasattr(t,'_ef_container'):
   x,y,w,h=t._ef_container;lo=a.transData.transform((x,y));hi=a.transData.transform((x+w,y+h))
   assert b.x0>=lo[0]+2 and b.x1<=hi[0]-2 and b.y0>=lo[1]+1 and b.y1<=hi[1]-1,(name,t.get_text(),'clipped',dict(text=[b.x0,b.y0,b.x1,b.y1],box=[*lo,*hi]))
 overlaps=[];crossings=[]
 for i,(t,b) in enumerate(bounds):
  for u,c in bounds[i+1:]:
   if min(b.x1,c.x1)-max(b.x0,c.x0)>.3 and min(b.y1,c.y1)-max(b.y0,c.y0)>.3:overlaps.append((t.get_text(),u.get_text()))
  for p,q in a._ef_segments:
   lo=a.transData.transform(p);hi=a.transData.transform(q)
   if abs(lo[0]-hi[0])<.01:hit=b.x0-1<lo[0]<b.x1+1 and min(hi[1],lo[1])<b.y1+1 and max(hi[1],lo[1])>b.y0-1
   elif abs(lo[1]-hi[1])<.01:hit=b.y0-1<lo[1]<b.y1+1 and min(hi[0],lo[0])<b.x1+1 and max(hi[0],lo[0])>b.x0-1
   else:raise AssertionError(('Routed connectors must be orthogonal',p,q))
   if hit:crossings.append((t.get_text(),p,q))
 assert not overlaps,(name,'text overlaps',overlaps)
 assert not crossings,(name,'connector/text intersections',crossings)
 for ext in ['pdf','svg','png']:f.savefig(OUT/f'{name}.{ext}',dpi=240,pad_inches=0)
 receipts.append(dict(figure=name,width_inches=float(f.get_size_inches()[0]),height_inches=float(f.get_size_inches()[1]),minimum_font_points=min(t.get_fontsize() for t in a.texts),text_blocks=len(a.texts),text_overlap_count=0,connector_text_intersection_count=0,container_clipping_count=0,visual_inspection_completed=False,sha256={ext:hashlib.sha256((OUT/f'{name}.{ext}').read_bytes()).hexdigest() for ext in ['pdf','svg','png']}));plt.close(f)

# 1. Vertical operator stack, with measured text/connector clearance.
f,a=sheet(250)
box(a,98,6,156,18,'2D image / 3D volume '+r'$x$','pink',9.0)
box(a,98,30,156,18,'Measurement adapter '+r'$\mathcal{A}$','pink',9.0)
arrow(a,(176,24),(176,30))
enclosure(a,48,49,256,71,'Field encoder')
box(a,60,54,232,18,'Response fields '+r'$r(p)\in\mathbb{R}^R$','orange')
box(a,60,78,232,18,'Associative sums '+r'$S_v,\ A_v$','blue')
box(a,60,102,232,18,'Region contrasts '+r'$\phi_v\in\mathbb{R}^D$','yellow')
for lo,hi in [(48,54),(72,78),(96,102)]:arrow(a,(176,lo),(176,hi))
enclosure(a,48,126,256,52,'Classifier')
box(a,58,130,108,18,r'$e_k(v)$','orange',9.1)
box(a,182,130,112,18,r'$p_k(G\mid v)$','orange',9.1)
route(a,[(176,120),(176,124),(112,124),(112,130)])
route(a,[(176,124),(238,124),(238,130)])
box(a,61,158,234,20,r'$F_k(v)=\max\{e_k(v),\Pi_k(v)\}$','violet')
route(a,[(112,148),(112,153),(176,153),(176,158)])
route(a,[(238,148),(238,153),(176,153)])
text(a,14,168,r'$H\times$',9.2,ha='center',va='center')
box(a,98,184,156,18,r'$z_k=F_k(0)+\beta_k$','violet')
arrow(a,(176,178),(176,184))
box(a,98,208,156,18,'Calibration '+r'$T_j$'+' / mixture '+r'$w_j$','green',9.0)
arrow(a,(176,202),(176,208));arrow(a,(176,226),(176,230))
text(a,176,239,r'$Q(y\mid x),\ \delta_\kappa(x)$',9.4,ha='center',va='center')
text(a,405,243,'Native evidence',9.5,ha='center',va='center',weight='bold')
box(a,334,121,142,28,'Per-member trace\n'+r'$\Omega_u,t_u,s_u,\mathrm{dep}_u$','blue',9.0)
route(a,[(254,193),(325,193),(325,131),(334,131)])
box(a,334,158,142,30,'Independent replay\n'+r'$\widehat\phi,\widehat F,\widehat z$','yellow',9.0)
arrow(a,(405,148),(405,158))
box(a,334,198,142,30,'Replay checks\n'+r'$\Delta z,\mathrm{cover},\mathrm{route}$','green',9.0)
arrow(a,(405,188),(405,198))
box(a,334,75,142,42,'Training operator\n'+r'$\mathrm{CE}+\lambda_p\mathrm{KL}$'+'\n'+r'$+\lambda_e\mathcal{L}_e$','pink',9.0)
route(a,[(295,168),(317,168),(317,96),(334,96)])
text(a,405,63,r'$\Pi_k=\max_{a,P}\mathrm{score}(a,P)$',8.8,ha='center')
save(f,a,'core_architecture')

# 2. A native half-column encoder panel, paired with the execution panel in the paper.
def half_sheet():
 f=plt.figure(figsize=(2.65,144/72));a=f.add_axes([0,0,1,1]);a.set(xlim=(0,190.8),ylim=(0,144));a.axis('off');a._ef_segments=[];return f,a
f,a=half_sheet()
box(a,7,5,176.8,22,r'$q(p)\in\mathbb{R}^6$','pink',9.1)
box(a,7,35,176.8,27,'Radial mixture\n'+r'$r=\alpha r_s+(1-\alpha)r_x$','orange',9.0)
box(a,7,70,176.8,30,'Associative sums\n'+r'$S=\mathrm{sum}\,rB,\quad A=\mathrm{sum}\,r e^{i\omega^Tu}$','blue',9.0)
box(a,7,108,176.8,26,'Normalization\n'+r'$f_v=(W,\nu,\Sigma_v,\Re C,\Im C)$','yellow',9.0)
for lo,hi in [(27,35),(62,70),(100,108)]:arrow(a,(95.4,lo),(95.4,hi))
save(f,a,'core_fields')

# 3. Complete score operands, partial occupancies, conservation and signed loss.
f,a=sheet(179)
box(a,7,122,147,43,'Own score\n'+r'$e_k^\tau(v)=\mu_v\operatorname{LSE}_{\tau}(\theta^T\phi_v)$','orange',9.0)
box(a,173,122,147,43,'Complete group score\n'+r'$p_k^\tau(G)=\mathrm{sum}_i\, e_k^\tau(i)+\mu_G c_k^\tau$','orange',9.0)
box(a,339,122,140,43,'Correction channels\n'+r'$c=c_{\mathrm{group}}+c_{\mathrm{parent}}$'+'\n'+r'$+c_{\mathrm{prod}}+c_{\mathrm{mod}}$','yellow',9.0)
arrow(a,(339,143),(320,143))
route(a,[(80,122),(80,108),(180,108),(180,97)])
box(a,7,63,147,34,'Smooth composition\n'+r'$F_k^\tau(0)$','blue')
arrow(a,(80,122),(80,97))
box(a,173,63,147,34,'Partial occupancies\n'+r'$\rho=\partial F/\partial e,\quad\sigma=\partial F/\partial p$','violet',9.0)
route(a,[(247,122),(247,109),(247,97)]);arrow(a,(154,80),(173,80))
box(a,339,63,140,34,'All-class signed field\n'+r'$\mathcal{E}_k^\tau=\sum\rho e K_v+\sum\sigma p K_G$','blue',8.8)
arrow(a,(320,80),(339,80))
box(a,7,5,230,43,r'$S_k^0=z_k^0-\beta_k$'+'\n'+r'$S_k^\tau=z_k^\tau-\beta_k-\mathcal{H}_{\mathrm{comp},k}$','green',9.0)
box(a,254,5,225,47,'Class-centred alignment\n'+r'$\widetilde{\mathcal{E}}_k=\mathcal{E}_k-\mathrm{mean}_j\,\mathcal{E}_j$'+'\n'+r'$\mathcal{L}_e=\mathrm{mean}_k\,d_s(\widetilde{\mathcal{E}}_k,T^{-1}\widetilde{\mathcal{E}}^\prime_k)$','pink',8.8)
route(a,[(410,63),(410,57),(365,57),(365,52)]);arrow(a,(80,63),(80,48))
save(f,a,'core_relations')

# 4. Native half-column direct executor and adjoint; evidence interface is in Fig. 1.
f,a=half_sheet()
box(a,7,5,176.8,22,r'$R_r(p),\ B_c(p)$','blue',9.1)
box(a,7,35,176.8,28,'Rectangle contraction\n'+r'$S_{vrc}=\mathrm{sum}_{\Omega_v}\,R_rB_c$','yellow',9.0)
box(a,7,71,176.8,39,'Shared adjoint\n'+r'$\partial_R\mathcal{L}=\mathrm{sum}_{v:p\in\Omega_v,c}\,g_{vrc}B_c$'+'\n'+r'$\partial_B\mathcal{L}=\mathrm{sum}_{v:p\in\Omega_v,r}\,g_{vrc}R_r$','orange',8.8)
arrow(a,(95.4,27),(95.4,35));arrow(a,(95.4,63),(95.4,71))
text(a,95.4,127,r'$T=N\sum_h A^h,\quad O(TRB)$',9.0,ha='center',va='center')
save(f,a,'core_execution')
(OUT/'Publication_Figure_Layout_QA.json').write_text(json.dumps(dict(layout_passed=True,figures=receipts,every_page_visual_qa_completed=False),indent=2)+'\n')
print('Four operator diagrams rendered; visual verification pending.')
