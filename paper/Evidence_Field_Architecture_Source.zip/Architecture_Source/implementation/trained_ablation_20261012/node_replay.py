"""Fresh NumPy/SciPy node-only reader; Torch must not be imported."""
from copy import deepcopy
import numpy as np


def verify_node_only(record, prepared, trusted_parameters, trusted_config, trusted_model_id, native_reader):
    if record.get('schema') != 'ef-node-only-certificate/1':
        raise ValueError('Node-only schema required')
    if record['config'] != trusted_config or record['model_id'] != trusted_model_id:
        raise ValueError('External model/configuration mismatch')
    expected = {'groups_allowed': False, 'partitions': trusted_config['alternatives'],
                'node_types': trusted_config['node_types'],
                'composition_options_per_internal_node': 1+trusted_config['alternatives'],
                'verification': 'Independent node-only grammar reader required'}
    if record['mechanism_contract'] != expected:
        raise ValueError('Node-only mechanism mismatch')
    g = record['geometry']
    if g['groups'] or g['packings'] != [[]] or g['orders']:
        raise ValueError('Group production found in node-only grammar')
    if np.asarray(g['incidence']).shape != (1, 0) or not np.array_equal(
            g['unmatched'], np.ones((1, 2**g['dim']))):
        raise ValueError('Invalid node-only packing incidence')
    if any(n in trusted_parameters for n in ('gamma', 'group_linear', 'member_projection', 'parent_projection')):
        raise ValueError('Unused group parameters found in node-only model')
    # Reader-only specialization of the independently enumerated grammar.
    # With maximum order one there are no eligible groups. Native inference
    # remains the registered node-only implementation, never a shadow model.
    c = deepcopy(record)
    c['schema'] = 'ef-adaptive-program-certificate/0.3'
    c['config']['max_order'] = 1
    result = native_reader.verify_adaptive(c, prepared, trusted_parameters,
        atol=2e-5, trusted_config=c['config'], trusted_model_id=trusted_model_id)
    if max(result['descriptor_error'], result['score_error'], result['optimum_error']) > 2e-5:
        raise ArithmeticError('Node-only strict replay tolerance failed')
    return result
