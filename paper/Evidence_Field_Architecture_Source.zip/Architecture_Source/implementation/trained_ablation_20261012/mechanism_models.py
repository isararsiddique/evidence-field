"""Isolated mechanism models; never modify the authenticated numerical package.

Import only after the source engine has authenticated the 30 frozen modules.
Node-only means removal of group productions, including their soft entropy,
not merely setting group corrections to zero in the larger grammar.
"""
from copy import deepcopy
from dataclasses import asdict, replace
from pathlib import Path
import sys
import numpy as np
import torch
from evidence_field.dense_program import DenseOpticalProgram


class NodeOnlyProgram(DenseOpticalProgram):
    def __init__(self, config):
        super().__init__(config)
        for name in ('group_linear', 'member_projection', 'parent_projection', 'gamma'):
            delattr(self, name)

    def layout(self, shape):
        g = super().layout(shape)
        if g['groups']:
            g = deepcopy(g)
            g['groups'] = []
            g['orders'] = []
            g['packings'] = [[]]
            g['incidence'] = np.zeros((1, 0), dtype=np.int64)
            g['unmatched'] = np.ones((1, 2**g['dim']), dtype=np.int64)
            self._geometry[tuple(shape)] = g
        return g

    def scored(self, phi, g, tau=0.):
        typed = torch.einsum('nvd,kmd->nvkm', phi, self.theta)
        reduced = tau*torch.logsumexp(typed/tau, -1) if tau > 0 else typed.max(-1).values
        mass = torch.as_tensor(g['mass'], device=phi.device, dtype=phi.dtype)
        own = reduced*mass[None, :, None]
        groups = own.new_zeros((len(phi), len(g['child_ids']), 0, self.config.classes))
        return own, groups, {'node_types': typed.argmax(-1),
                            'group_types': torch.zeros_like(groups, dtype=torch.long)}

    def certificate(self, x, spacing=None):
        record = super().certificate(x, spacing)
        record['schema'] = 'ef-node-only-certificate/1'
        record['mechanism_contract'] = {
            'groups_allowed': False, 'partitions': self.config.alternatives,
            'node_types': self.config.node_types,
            'composition_options_per_internal_node': 1+self.config.alternatives,
            'verification': 'Independent node-only grammar reader required'}
        return record


class PooledReadoutProgram(NodeOnlyProgram):
    """Same encoder and descriptors, no covering optimization in the readout."""
    def compose(self, own, group_scores, g, tau=0., trace=False):
        if trace:
            raise ValueError('Pooled readout has no selected covering program')
        # Every level has root mass times alternatives**level; normalize reuse.
        normalizer = torch.as_tensor(g['mass'], device=own.device, dtype=own.dtype).sum()
        return own.sum(1)/normalizer+self.bias

    def certificate(self, x, spacing=None):
        raise ValueError('Pooled controls must not export a covering certificate')


VARIANTS = ('full_dense', 'full_direct', 'gaussian_closure', 'no_explicit_parent',
            'node_only', 'node_only_capacity', 'full_reduced_capacity',
            'single_partition', 'fixed_frequency', 'no_multiplicative_interaction',
            'pooled_linear', 'pooled_capacity')


def build_control(base, variant, architecture):
    if variant not in VARIANTS:
        raise ValueError('Unregistered mechanism')
    sys.path.insert(0, str(architecture))
    from descriptor_controls.control_model import DescriptorControl, DescriptorControlConfig, parameter_accounting
    c = base.config
    if variant == 'full_dense':
        model = base
    elif variant == 'full_direct':
        from cost_backend.direct_support import install_direct_support
        model = install_direct_support(base)
    elif variant == 'gaussian_closure':
        from gaussian_control.gaussian_model import GaussianRepresentationConfig, GaussianOpticalProgram
        model = GaussianOpticalProgram(GaussianRepresentationConfig(**asdict(c)))
        model.load_state_dict(base.state_dict(), strict=True)
    elif variant in ('no_explicit_parent', 'fixed_frequency'):
        model = DescriptorControl(DescriptorControlConfig(**asdict(c), descriptor_control=variant))
        model.load_state_dict(base.state_dict(), strict=True)
    elif variant == 'no_multiplicative_interaction':
        model = base
        with torch.no_grad():
            model.gamma.zero_()
        for p in (model.gamma, model.member_projection, model.parent_projection):
            p.requires_grad_(False)
    elif variant == 'single_partition':
        model = DenseOpticalProgram(replace(c, alternatives=1))
        model.load_state_dict(base.state_dict(), strict=True)
    elif variant == 'full_reduced_capacity':
        # 7,074 coordinates vs 7,074 nominal remaining in no-explicit-parent.
        model = DenseOpticalProgram(replace(c, node_types=3, pair_types=1))
    elif variant.startswith('node_only'):
        model = NodeOnlyProgram(replace(c, node_types=12 if variant.endswith('capacity') else 2))
    elif variant.startswith('pooled'):
        model = PooledReadoutProgram(replace(c, node_types=12 if variant.endswith('capacity') else 1))
    if variant.startswith('node_only') or variant.startswith('pooled') or variant == 'full_reduced_capacity':
        # Copy only identical encoder buffers/parameters; own/type banks use the
        # same seed + 29 initializer at their declared dimensions.
        model.encoder.load_state_dict(base.encoder.state_dict(), strict=True)
    counts = {'registered_parameters': sum(p.numel() for p in model.parameters()),
              'requires_grad_parameters': sum(p.numel() for p in model.parameters() if p.requires_grad),
              'variant': variant, 'descriptor_width': model.width,
              'capacity_scope': 'Coordinate counts, not functional rank or 2D-active dimension'}
    if variant in ('no_explicit_parent', 'fixed_frequency'):
        counts.update(parameter_accounting(model))
    counts['reference_parameters'] = 10550
    counts['reference_count_difference'] = counts['requires_grad_parameters']-10550
    counts['readout'] = 'pooled typed affine' if variant.startswith('pooled') else 'exact registered cover'
    counts['backend'] = 'direct_rectangular_fp64' if variant in ('full_direct', 'gaussian_closure') else 'dense_fp64'
    model.mechanism_accounting = counts
    return model
