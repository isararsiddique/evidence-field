"""Check the publication package; no training or network calls."""
from pathlib import Path
import hashlib, json
P = Path(__file__).resolve().parent
m = json.loads((P / "Publication_Payload_Hashes.json").read_text())
for r in m["files"]:
    f = P / r["file"]
    assert f.stat().st_size == r["bytes"] and hashlib.sha256(f.read_bytes()).hexdigest() == r["sha256"], r["file"]
a = json.loads((P / "audit/Histopathology_Architecture_Training_Check.json").read_text())
assert a["passed"] and a["architecture"]["completed_new_fits"] == 25
s = {x: json.loads((P / f"audit/{x}_Statistics.json").read_text()) for x in ("source_test", "hospital_1", "hospital_2")}
t = (P / "application_summary.tex").read_text()
for name in ("full_dense", "full_direct", "gaussian_closure", "no_explicit_parent", "node_only", "node_only_capacity", "full_reduced_capacity", "single_partition", "original_signed", "class_centred_objective"):
    values = [f"{s[x]['points'][name+'__raw']['auroc']:.4f}" for x in s]
    assert " & ".join(values) in t, (name, values)
c = json.loads((P / "audit/Completed_Evidence_Inputs_and_Citations.json").read_text())
assert c["passed"] and c["journal_research_method_references_2015_onward"] >= 30
assert c["unpublished_companions"] == ["ef_hist"] and not c["3D_application_validation_claim"]
h = json.loads((P / "audit/Histology_Full_Prediction_Statistics.json").read_text())
for pool in ("hospital_1", "hospital_2"):
    values = [h["pools"][pool]["ensemble_metrics"][name]["raw"] for name in ("ef_two_ce", "cnn", "vit")]
    cells = [f"{x['auroc']:.4f} / {100*x['accuracy']:.2f}" for x in values]
    assert " & ".join(cells) in t
g = json.loads((P / "audit/technical/CAMELYON_Only_Loss_Correctness.json").read_text())
assert g["dataset"] == "camelyon" and g["shared_offset_checks"] == 48 and g["finite_difference_checks"] == 24
assert g["no_optimizer_steps"] and all(r["dataset"] == "camelyon" for r in g["rows"] + g["gradient_checks"])
public=json.loads((P/'audit/GitHub_Public_Reproduction_Verification.json').read_text())
assert public['independent_reader']['passed'] and public['original_model_cpu_check']['passed']
assert public['public_payload_hashes_verified']==89
worked=json.loads((P/'audit/Worked_Evidence_Example.json').read_text())
assert worked['released_label']==0
print(f"Verified {len(m['files'])} payloads, 10 trained-table rows and completed source-only records.")
