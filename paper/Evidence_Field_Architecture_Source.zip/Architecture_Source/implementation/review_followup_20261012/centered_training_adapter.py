"""Isolated centred-loss fits using the unchanged full-source training engine.

No frozen module is edited. The private, fresh-process objective replaces only
the uncentred distance. Every checkpoint identifies the amended protocol.
"""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,sys

HERE=Path(__file__).resolve().parent
ROOT=Path(os.environ.get('EF_RESEARCH_ROOT','/home/ubuntu/evidence_field_next_20261011_multi_gpu'))
APP=ROOT/'application_studies'
ENGINE=APP/'architecture_revision_v05/histology_training_extension/new_full_source'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source_prepared():
    receipt=APP/'histopathology/new_full_source_study/camelyon/input_receipt.json'
    return Path(json.loads(receipt.read_text())['prepared_path'])
def engine():
    sys.path.insert(0,str(ENGINE))
    spec=importlib.util.spec_from_file_location('_centred_private_fit_engine',ENGINE/'train_source_fit.py')
    fit=importlib.util.module_from_spec(spec);sys.modules[spec.name]=fit;spec.loader.exec_module(fit)
    original_protocol=fit.protocol
    def protocol():
        d=original_protocol()
        d.update(schema='class-centred-full-source-objective-comparison/1',
          design='Three new full-source centred signed-evidence fits, compared with six preserved paired-CE/original-signed fits',
          datasets=['camelyon'],methods=['ef_signed'],fits_per_dataset=3,
          variant_selection='No comparison variant is selected by external outcomes; report every source-selected objective',
          target_gate='This engine opens only source train/validation. All three amended fits must finish and lock before separate target evaluation.',
          candidate_contract={'variant':'centred signed evidence','original_engine_sha256':sha(ENGINE/'train_source_fit.py'),
              'adapter_sha256':sha(Path(__file__)),'loss_sha256':sha(HERE/'gauge_invariant_loss.py'),
              'baseline_source_lock_sha256':sha(APP/'histopathology/new_full_source_study/camelyon/source_checkpoint_lock.json'),
              'source_input_receipt_sha256':sha(APP/'histopathology/new_full_source_study/camelyon/input_receipt.json'),
              'prepared_path':str(source_prepared()),
              'frozen_numerical_modules_changed':False,'objective_only_change':True,'old_fits_reinterpreted':False})
        d['objective']={'ef_signed':{'views':2,'probability_kl':.05,'signed_all_class_l1':.02,
           'centering':'Pointwise class mean removed separately from both inverse-aligned maps; original fields retained for score accounting'}}
        return d
    fit.protocol=protocol
    r=fit.runtime()
    from gauge_invariant_loss import torch_distance
    from torch.nn import functional as F
    signed=r['signed']
    def paired_loss(model,x,y,rotation,flip,tau,probability_weight=.05,evidence_weight=.02):
        transform=r['AxialRigid'](int(rotation),bool(flip))
        first=signed.signed_forward(model,x,tau)
        second=signed.signed_forward(model,transform.apply(x),tau)
        ce=.5*(F.cross_entropy(first['logits'],y)+F.cross_entropy(second['logits'],y))
        kl=r['symmetric_probability_kl'](first['logits'],second['logits'])
        distance=torch_distance(first['class_density'],transform.inverse(second['class_density']))
        return ce+probability_weight*kl+evidence_weight*distance,dict(ce=ce,probability_kl=kl,
            signed_distance=distance,first=first,second=second)
    signed.paired_loss=paired_loss
    return fit
def main():
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,choices=[11,29,47],required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--execute',action='store_true')
    args=p.parse_args();fit=engine()
    if not args.execute:raise SystemExit('Execution must be explicit')
    qa=json.loads((HERE/'Centered_Source_CPU_QA.json').read_text())
    assert qa['passed'] and qa['adapter_sha256']==sha(Path(__file__)) and qa['loss_sha256']==sha(HERE/'gauge_invariant_loss.py')
    fit.run_fit('camelyon','ef_signed',args.seed,source_prepared(),args.output,'cuda:0',4)
if __name__=='__main__':main()
