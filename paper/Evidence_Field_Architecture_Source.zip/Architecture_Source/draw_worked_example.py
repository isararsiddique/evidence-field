"""Real pathology input, unchanged selected cover and signed-score accounting."""
from pathlib import Path
import json, hashlib
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.colors import TwoSlopeNorm

C = Path(__file__).resolve().parent
P = C / "reproduction"
if not (P / "Worked_Evidence_Example.json").is_file():
    P = P / "Evidence_Field_Reproduction"
O = C / "figures"
d = json.loads((P / "Worked_Evidence_Example.json").read_text())
r = json.loads((P / "example_seed_11.json").read_text())
x = np.load(P / "example_input.npy", allow_pickle=False)
assert d["passed"] and d["predicted_label"] != d["released_label"]
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8,
                     "pdf.fonttype": 42, "svg.fonttype": "none"})
f = plt.figure(figsize=(5.5, 1.92))
axes = [f.add_axes([l, .35, .188, .54]) for l in (.01, .215, .420)]
for a in axes:
    a.set(xlim=(-.5, 95.5), ylim=(95.5, -.5))
    a.set_xticks([]); a.set_yticks([])
    for spine in a.spines.values(): spine.set_linewidth(.6)
rgb = np.moveaxis(x, 0, -1)
axes[0].imshow(rgb, interpolation="nearest")
axes[0].add_patch(Rectangle((31.5, 31.5), 32, 32, fc="none", ec="white", ls="--", lw=.8))
axes[0].set_title("Input / central label", fontsize=8, pad=5)
axes[1].imshow(rgb, interpolation="nearest", alpha=.28)
bounds = np.array(r["geometry"]["bounds"])
cover = np.zeros((96, 96), int)
units = r["classes"][1]["units"]
cmap = plt.get_cmap("tab20")
for i, u in enumerate(units):
    for node in u["nodes"]:
        (yl, yh), (xl, xh) = bounds[node]
        cover[yl:yh, xl:xh] += 1
        axes[1].add_patch(Rectangle((xl-.5, yl-.5), xh-xl, yh-yl,
                                   fc=cmap(i), alpha=.62, ec="#25364a", lw=.7))
assert np.all(cover == 1)
axes[1].set_title("Class 1 cover", fontsize=8, pad=5)
fields = np.zeros((2, 96, 96))
for k, row in enumerate(r["classes"]):
    for u in row["units"]:
        area = sum(np.prod(bounds[n, :, 1] - bounds[n, :, 0]) for n in u["nodes"])
        for n in u["nodes"]:
            (yl, yh), (xl, xh) = bounds[n]
            fields[k, yl:yh, xl:xh] += u["score"] / area
margin = (fields[1] - fields[0]) * (96*96)
limit = float(np.max(np.abs(margin)))
im = axes[2].imshow(margin, interpolation="nearest", cmap="RdBu_r",
                    norm=TwoSlopeNorm(vmin=-limit, vcenter=0, vmax=limit))
axes[2].set_title("Signed margin field", fontsize=8, pad=5)
cb = f.colorbar(im, cax=f.add_axes([.440, .235, .150, .04]), orientation="horizontal")
cb.set_ticks([-limit, 0, limit]); cb.ax.tick_params(labelsize=6.7, length=2, pad=1)
f.text(.103, .245, "Released y = 0", ha="center", fontsize=7.7)
f.text(.309, .245, f"{len(units)} disjoint units", ha="center", fontsize=7.7)
f.text(.515, .080, "Blue: 0; red: 1", ha="center", fontsize=7.0)

# Both class scores and their contrast share the same exact six-term accounting.
rows = d["members"][0]["audit"]["classes"]
names = ["anchors", "local_affine", "parent_affine", "member_product", "parent_modulation", "bias"]
labels = ["Anchors", "Group affine", "Parent affine", "Product", "Modulation", "Bias"]
f.text(.63, .95, "Signed totals, seed 11", fontsize=8, weight="bold")
f.text(.82, .84, "Class 0", ha="right", fontsize=7.5)
f.text(.99, .84, "Class 1", ha="right", fontsize=7.5)
for i, (key, label) in enumerate(zip(names, labels)):
    y = .748 - i*.083
    f.text(.63, y, label, fontsize=7.3)
    for j, row in enumerate(rows):
        value = row["signed_totals"][key]
        f.text(.82+j*.17, y, f"{value:+.3f}", ha="right", fontsize=7.3,
               color="#a52b29" if value >= 0 else "#24508b")
f.add_artist(plt.Line2D([.63, .99], [.275, .275], transform=f.transFigure, color="#25364a", lw=.6))
for j, row in enumerate(rows):
    f.text(.82+j*.17, .200, f"{row['reconstructed_logit']:.3f}", ha="right", fontsize=7.8, weight="bold")
f.text(.63, .200, "Sum = logit", fontsize=7.3)
f.text(.63, .085, "Raw ensemble P(1) = 0.8876", fontsize=7.4)
f.canvas.draw()
renderer = f.canvas.get_renderer()
texts = list(f.texts)
for a in axes: texts.append(a.title)
rects = [(t, t.get_window_extent(renderer)) for t in texts]
for t, b in rects:
    assert 0 <= b.x0 < b.x1 <= f.bbox.width and 0 <= b.y0 < b.y1 <= f.bbox.height, t.get_text()
for i, (t, b) in enumerate(rects):
    for u, c in rects[i+1:]:
        assert min(b.x1,c.x1)-max(b.x0,c.x0) <= .3 or min(b.y1,c.y1)-max(b.y0,c.y0) <= .3, (t.get_text(),u.get_text())
for ext in ("pdf", "svg", "png"):
    f.savefig(O / f"core_worked_example.{ext}", dpi=300)
receipt = dict(passed=True, real_input=True, incorrect_prediction=True, selected_cover_onefold=bool(np.all(cover==1)),
               scores_reconstructed_from_components=True, rounded_values_for_display_only=True,
               field_display="N*(class-1 hard field - class-0 hard field); bias excluded; no saliency or clinical localization claim",
               text_overlap_count=0, container_clipping_count=0, visual_inspection_completed=False,
               sha256={e:hashlib.sha256((O/f"core_worked_example.{e}").read_bytes()).hexdigest() for e in ("pdf","svg","png")})
(O/"Worked_Example_Figure_QA.json").write_text(json.dumps(receipt,indent=2)+"\n")
print("Worked example figure rendered; independent signed totals retained.")
