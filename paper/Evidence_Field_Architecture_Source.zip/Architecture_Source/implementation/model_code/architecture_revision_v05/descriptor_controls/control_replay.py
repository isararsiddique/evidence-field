"""Independent NumPy/SciPy reader for the separately versioned EF controls.

For moments-only Mφ, a binary diagonal mask M commutes with weighted means
and absolute spreads, and (aᵀMφ)=(Ma)ᵀφ. Projecting authenticated coefficient
coordinates therefore gives an equivalent raw-descriptor covering program.
The shadow program is used only inside this audit and never replaces the original
certificate/model. Original masked descriptors are independently verified first.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib
import importlib.abc
import json
import sys
import numpy as np
from bootstrap import bind_frozen_source

VERSION = 'ef-descriptor-controls/0.5.0'
SCHEMA = 'ef-descriptor-control-certificate/0.5.0'
MODES = ('learned_frequency', 'fixed_frequency', 'moments_only', 'no_explicit_parent')


class ForbidTorch(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'torch' or fullname.startswith('torch.'):
            raise ImportError('Descriptor-control independent reader forbids Torch')


def mask_for(config):
    per_response = 10 + 2 * config['frequencies']
    field_width = config['responses'] * per_response
    mask = np.ones(3 * field_width + 3, dtype=np.float64)
    if config['descriptor_control'] == 'moments_only':
        for block in range(3):
            for response in range(config['responses']):
                start = block * field_width + response * per_response + 10
                mask[start:start + 2 * config['frequencies']] = 0
    return mask


def projected_parameters(parameters, mask):
    projected = {name: np.asarray(value, np.float64).copy() for name, value in parameters.items()}
    projected['theta'] *= mask
    projected['group_linear'] *= np.r_[mask, mask[:-1], mask]
    projected['member_projection'] *= mask[:-1]
    projected['parent_projection'] *= mask[:-1]
    return {name: value.tolist() for name, value in projected.items()}


def canonical_raw_wavevectors(frequencies, frequency_limit):
    directions = np.array([[0, 1, 0], [0, 2, 0], [0, 0, 1], [1, 0, 0]], float)
    initial = np.stack([3*np.pi*directions[t % 4] / (1+t//4) for t in range(frequencies)])
    return np.arctanh(np.clip(initial/frequency_limit, -.95, .95)).astype(np.float32)


def verify_external_state(trust):
    """Rebuild the fingerprint from external tensor names, dtypes and bytes."""
    parameters = trust['parameters']; registry = trust['state_registry']
    if len(registry) != len(parameters) or set(r['name'] for r in registry) != set(parameters):
        raise ValueError('Externally authenticated state registry mismatch')
    digest = hashlib.sha256(json.dumps(trust['config'], sort_keys=True).encode())
    for row in registry:
        value = np.ascontiguousarray(np.asarray(parameters[row['name']], dtype=np.dtype(row['dtype'])))
        if list(value.shape) != row['shape'] or not np.isfinite(value).all():
            raise ValueError('Trusted tensor shape/nonfinite value mismatch')
        if hashlib.sha256(value.tobytes()).hexdigest() != row['sha256']:
            raise ValueError('Trusted tensor byte identity mismatch')
        digest.update(row['name'].encode()); digest.update(value.tobytes())
    if digest.hexdigest() != trust['model_id']:
        raise ValueError('Externally authenticated model fingerprint mismatch')


def verify_control(record, prepared, trust, native_reader, tolerance=1e-3):
    if record.get('schema') != SCHEMA:
        raise ValueError('Separate descriptor-control certificate schema required')
    verify_external_state(trust)
    config = record['config']
    if config.get('descriptor_control_version') != VERSION or config.get('descriptor_control') not in MODES:
        raise ValueError('Wrong descriptor-control contract')
    if config['responses'] != 8 or config['frequencies'] != 4 or not config['learned_encoder']:
        raise ValueError('Registered R8/L4 learned-radial comparison required')
    mode = config['descriptor_control']
    if config['learned_frequencies'] != (mode in ('learned_frequency', 'no_explicit_parent')):
        raise ValueError('Frequency learning flag differs from registered control')
    if config['cross_scale'] != (mode != 'no_explicit_parent'):
        raise ValueError('Additional parent-context flag differs from registered control')
    if config != trust['config'] or record['model_id'] != trust['model_id']:
        raise ValueError('External model/configuration identity mismatch')
    if record.get('control_contract') != trust['control_contract']:
        raise ValueError('External descriptor-control contract mismatch')
    if record['input_sha256'] != trust['prepared_input_sha256']:
        raise ValueError('Externally authenticated prepared input identity mismatch')
    if record.get('source_input_binding') != trust['source_input_binding']:
        raise ValueError('External source-input binding mismatch')
    if set(record['parameters']) != set(trust['parameters']):
        raise ValueError('Parameter registry mismatch')
    for name, value in trust['parameters'].items():
        if not np.array_equal(np.asarray(value), np.asarray(record['parameters'][name])):
            raise ValueError('Authenticated original coefficient mismatch: ' + name)
    if not config['learned_frequencies']:
        expected = canonical_raw_wavevectors(config['frequencies'], config['frequency_limit'])
        actual = np.asarray(record['parameters']['encoder.raw_wavevectors'], np.float32)
        if not np.array_equal(expected, actual):
            raise ValueError('Fixed-frequency bank differs from the canonical source declaration')
    raw_phi = native_reader.independent_phi(record, prepared)
    mask = mask_for(config)
    independently_masked = raw_phi * mask
    declared = np.asarray(record['phi'], np.float64)
    if declared.shape != independently_masked.shape:
        raise ValueError('Control descriptor dimensions differ')
    if np.any(declared[:, mask == 0] != 0):
        raise ValueError('Moments-only certificate contains nonzero signature coordinates')
    error = float(np.abs(independently_masked - declared).max())
    if not np.isfinite(declared).all() or error > tolerance:
        raise ArithmeticError('Independent control descriptor replay mismatch')
    # This identity uses independently computed original-image descriptors and
    # a deterministic projection of externally authenticated coefficients.
    shadow = copy.deepcopy(record)
    shadow['schema'] = 'ef-adaptive-program-certificate/0.3'
    # Retain authenticated FP32 rounding on active coordinates. Masked raw
    # coordinates have zero projected coefficients and cannot change a score.
    shadow['phi'] = np.where(mask, declared, raw_phi).tolist()
    shadow['parameters'] = projected_parameters(trust['parameters'], mask)
    native = native_reader.verify_adaptive(shadow, prepared, shadow['parameters'],
        trusted_config=trust['config'], trusted_model_id=trust['model_id'])
    return dict(passed=True, descriptor_control=mode, version=VERSION,
                maximum_control_descriptor_error=error, native_equivalent_program_audit=native,
                masked_descriptor_coordinates=int(np.count_nonzero(mask == 0)),
                original_model_id=record['model_id'], input_sha256=record['input_sha256'],
                score_equivalence='Binary coordinate masks commute with means/absolute spreads and linear projections; authenticated projected coefficients preserve the original masked program',
                training_framework_imported=False,
                scope='Prepared real-image descriptor, admissible cover and complete class-logit replay; no trained accuracy or clinical certification claim')


def run(args):
    if any(name == 'torch' or name.startswith('torch.') for name in sys.modules):
        raise RuntimeError('Use a fresh independent-reader process')
    sys.meta_path.insert(0, ForbidTorch())
    binding = bind_frozen_source(args.application_dir)
    native = importlib.import_module('evidence_field.adaptive_replay')
    trust_bytes = Path(args.trust_json).read_bytes()
    if hashlib.sha256(trust_bytes).hexdigest() != args.trust_sha256:
        raise ValueError('Externally supplied trust-file digest mismatch')
    trust = json.loads(trust_bytes); record = json.loads(Path(args.record).read_text())
    prepared_bytes = Path(args.prepared).read_bytes()
    if hashlib.sha256(prepared_bytes).hexdigest() != trust['prepared_file_sha256']:
        raise ValueError('Externally supplied prepared-file digest mismatch')
    prepared = np.load(args.prepared, allow_pickle=False)
    if not isinstance(prepared, np.ndarray):
        raise ValueError('One explicitly bound prepared array is required, not an NPZ container')
    result = verify_control(record, prepared, trust, native)
    result.update(checkpoint_sha256=trust['checkpoint_sha256'], trust_sha256=args.trust_sha256,
                  record_sha256=hashlib.sha256(Path(args.record).read_bytes()).hexdigest(),
                  prepared_file_sha256=hashlib.sha256(Path(args.prepared).read_bytes()).hexdigest(),
                  numerical_source_snapshot_sha256=binding['snapshot_sha256'],
                  reader_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  native_reader_sha256=hashlib.sha256((binding['source_dir'] / 'evidence_field/adaptive_replay.py').read_bytes()).hexdigest())
    assert not any(name == 'torch' or name.startswith('torch.') for name in sys.modules)
    Path(args.output).write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    for name in ['application-dir', 'trust-json', 'trust-sha256', 'record', 'prepared', 'output']:
        p.add_argument('--' + name, required=True)
    run(p.parse_args())
