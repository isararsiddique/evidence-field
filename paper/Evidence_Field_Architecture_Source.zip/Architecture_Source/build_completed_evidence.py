"""Build the core paper's classification/evidence section from audited results.

This is a prediction-table release, not the unfinished integrated
prediction/stability/cost table in trained_ablation_20261012.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import re

C = Path(__file__).resolve().parent
W = C.parent
ROOT = W.parents[1]
V = ROOT / "outputs/Evidence_Field_Next_Research/Verified_v04"
audit = json.loads((C / "Histopathology_Architecture_Training_Check.json").read_text())
assert audit["passed"]
assert audit["architecture"]["completed_new_fits"] == 25
assert len(audit["prediction_checks"]["checkpoint_bound_prediction_receipts"]) == 126
H = json.loads((V / "Histology_Full_Prediction_Statistics.json").read_text())
primary_ci = [H["pools"][p]["raw_uncertainty"]["intervals"]["ef_two_ce"]["auroc"] for p in ("hospital_1", "hospital_2")]
primary_ci_text = "/".join(f"$[{x['lower']:.4f},{x['upper']:.4f}]$" for x in primary_ci)
paired_ci = {p:{r["second"]:r["difference_first_minus_second"]["auroc"]
                for r in H["pools"][p]["raw_uncertainty"]["paired"]
                if r["first"] == "ef_two_ce" and r["second"] in ("cnn", "vit")}
             for p in ("hospital_1", "hospital_2")}
paired_ci_text = {p:"/".join(f"$[{paired_ci[p][m]['lower']:.4f},{paired_ci[p][m]['upper']:.4f}]$"
                             for m in ("cnn", "vit")) for p in paired_ci}
S = {p: json.loads((V / f"Completed_Architecture_Statistics/{p}_Statistics.json").read_text()) for p in ("source_test", "hospital_1", "hospital_2")}
assert all(x["completed"] and x["source_selection_only"] and not x["target_tuning"] for x in S.values())

lines = [
    r"\paragraph{Source-only training and evaluation.}",
    r"The histopathology companion~\cite{ef_hist} trains six from-scratch recipes, seeds 11/29/47, for 16 epochs (18 fits). CAMELYON17~\cite{camelyon} centres 0/3/4 supply 271,010 training, 24,982 validation and 40,004 source-test patches; centres 1/2 supply 34,904/85,054 patches from 8/9 development-disjoint patients. All 455,954 patches are included. The binary lymph-node task has two held-out hospitals within one dataset.",
    r"The wltjr1007 CAMELYON17-WILDS mirror supplies inputs; decoded-image/LFS checks do not authenticate original-publisher bytes. Source training/validation/test contain 20/3/3 patients: retained training IDs, then alternating sorted remaining source IDs, without labels. The artifact records exact IDs and manifest hashes. Previously examined targets make this source-locked replication, not prospective validation or the standard WILDS protocol.",
    r"",
    r"Shared inputs are $96\times96$ RGB. AdamW uses EF/baseline rates 0.003/0.001, decay $10^{-4}$, cosine scheduling, clipping 5, batch size 64 and unweighted CE. Comparators are ResNet18 and a four-block, width-128 ViT with $8\times8$ patches. Source validation selects state, objective, calibration and review thresholds. Four EF objectives versus one CNN/ViT configuration leave unequal tuning; held-out outcomes do not select models.",
    r"",
    r"\begin{table}[ht]\centering\small",
    r"\caption{Histopathology companion: raw three-member ensemble AUROC / accuracy (\%), fixed argmax. $N$ counts patches, parentheses patients; EF is source-selected paired CE.}\label{ef:companion_results}",
    r"\begin{tabular}{@{}lrrrr@{}}\toprule",
    r"Evaluation & $N$ (patients) & EF & CNN & ViT\\\midrule",
]
for p, label in [("hospital_1", "CAMELYON centre 1"), ("hospital_2", "CAMELYON centre 2")]:
    row = [H["pools"][p]["ensemble_metrics"][m]["raw"] for m in ("ef_two_ce", "cnn", "vit")]
    count, patients = S[p]["count"], S[p]["patients"]
    vals = [f"{x['auroc']:.4f} / {100*x['accuracy']:.2f}" for x in row]
    lines.append(f"{label} & {count:,} ({patients}) & " + " & ".join(vals) + r"\\")
lines += [
    r"\bottomrule\end{tabular}\end{table}",
    r"\begingroup\raggedright EF's 95\% patient-bootstrap AUROC intervals (2,000 resamples) are " + primary_ci_text + r". Paired EF--CNN/EF--ViT difference intervals are " + paired_ci_text["hospital_1"] + r" (centre 1), " + paired_ci_text["hospital_2"] + r" (centre 2). Whole-patient resampling retains patch multiplicity. These exploratory, multiplicity-unadjusted intervals and unequal tuning/small patient counts constrain superiority claims.\par\endgroup",
    r"",
    r"\paragraph{Trained mechanism and corrected-loss comparisons.}",
    r"Seven mechanism triplets and three centred-loss fits add 24 evaluated fits (16 epochs each); one learning-rate fit is source-only. Every new row is separately trained: the direct-contraction row is three new fits, not numerical reevaluation of the dense checkpoints. All 72 prediction files and three patient-statistics reports are complete; external scores do not select a replacement primary model.",
    r"\begin{table}[ht]\centering\small",
    r"\caption{Three-member raw-probability ensemble AUROC; registered $n_\Theta$ per member. No-parent masking leaves 7,074 nominal unmasked coordinates.}\label{ef:trained_ablation}",
    r"\begin{tabular}{@{}lrrrr@{}}\toprule",
    r"Representation / composition / objective & $n_\Theta$ & Source test & Centre 1 & Centre 2\\\midrule",
]
names = [
    ("full_dense", "Full EF, paired CE (reference)", 10550),
    ("full_direct", "Full EF, direct contractions", 10550),
    ("gaussian_closure", "Moment-based Gaussian closure", 10550),
    ("no_explicit_parent", "No explicit parent correction", 10550),
    ("node_only", "Node-only covering", 1858),
    ("node_only_capacity", "Node-only, enlarged capacity", 10558),
    ("full_reduced_capacity", "Full EF, reduced capacity", 7074),
    ("single_partition", "Single fixed partition", 10550),
    ("original_signed", "Original signed objective (reference)", 10550),
    ("class_centred_objective", "Class-centred signed objective", 10550),
]
for entry, label, count in names:
    vals = [f"{S[p]['points'][entry+'__raw']['auroc']:.4f}" for p in ("source_test", "hospital_1", "hospital_2")]
    lines.append(f"{label} & {count:,} & " + " & ".join(vals) + r"\\")
lines += [
    r"\bottomrule\end{tabular}\end{table}",
    r"\noindent\begin{minipage}{\linewidth}",
    r"Gaussian closure derives signatures from moments using the same head/backend. Gaussian closure and the fixed partition both exceed primary EF at both hospitals on point estimates. Learned signatures and adaptive partitions therefore have unestablished predictive benefit here; their mathematical expressivity and covering properties are separate. Direct-full-minus-closure intervals are $[-0.0175,0.0016]$/$[-0.0494,0.0065]$. Parent removal retains contrasts; node-only removes groups; capacity effects are mixed. Centred-minus-original signed changes are $-0.0012$/$+0.0043$, with intervals $[-0.0064,0.0021]$/$[-0.0074,0.0260]$. Offset invariance does not establish predictive/stability gains.",
    r"\end{minipage}",
    r"",
    r"\paragraph{Native outputs and reproducibility.}",
    r"Each input returns probability/review status, all member/class supports/types, signed anchors, four corrections and dependencies. Table~\ref{ef:technical_checks} covers 340 images, all 17 held-out patients and three seeds/views. The comparators lack this native covering-program contract; clinical relevance needs separate assessment. All 126 prediction files bind state/input/patient identities; 949 payloads and 336 metrics reproduce within $8.25\times10^{-13}$. Centred-model 50\% nominal source retention transfers to 39.81\%/18.14\%, with error 0.99\%/0.86\%; this is not a safety guarantee. Variant-specific aligned stability/full replay, isolated GPU energy and matched baseline tuning remain unmeasured.",
]
(C / "application_summary.tex").write_text("\n".join(lines) + "\n")

# Rebuild only this paper. Shared helpers' main() would also overwrite companions.
spec = importlib.util.spec_from_file_location("verified_core_refs", W / "application_studies/build_verified_bibliographies.py")
refs = importlib.util.module_from_spec(spec)
spec.loader.exec_module(refs)
j = json.loads((refs.LIT / "journal_source_audit.json").read_text())["records"]
p = json.loads((refs.LIT / "proceedings_source_audit.json").read_text())["records"]
catalog = {r["key"]: dict(r, publication_kind="journal") for r in j if r["verified_published_journal"]}
catalog.update({r["key"]: r for r in p if r["verified"]})
retained = json.loads((C / "published_reference_audit.json").read_text())["records"]
for r in retained:
    if r["key"] not in ("spatialpyramid", "ruleensemble"):
        continue
    assert r["publication_identity_verified"] and r["openalex_metadata"]["verified"]
    b = r["openalex_metadata"]["biblio"]
    names = ([{"given": "Svetlana", "family": "Lazebnik"}, {"given": "Cordelia", "family": "Schmid"}, {"given": "Jean", "family": "Ponce"}]
             if r["key"] == "spatialpyramid" else [{"given": "Jerome H.", "family": "Friedman"}, {"given": "Bogdan E.", "family": "Popescu"}])
    catalog[r["key"]] = dict(r, primary_url="https://doi.org/" + r["doi"], authors=names,
                             container="CVPR" if r["key"] == "spatialpyramid" else "The Annals of Applied Statistics",
                             publication_kind="conference" if r["key"] == "spatialpyramid" else "journal",
                             volume=b["volume"] if r["key"] == "ruleensemble" else None, issue=b["issue"],
                             pages=b["first_page"] + "--" + b["last_page"])
companions = {
    "ef_hist": r"\bibitem{ef_hist} Isarar Siddique et al. Evidence Field for Histopathology: Native Predictions and Replayable Spatial Programs. Unpublished companion research manuscript, Convolity AI Lab, 2026.",
}
keys = refs.cited_keys(C / "Evidence_Field_Core.tex")
assert "ef_hist" in keys and "ef_ct" not in keys
assert all(k in catalog or k in companions for k in keys)
published = [catalog[k] for k in keys if k in catalog]
excluded = {"litjens", "geirhos", "rudin", "grammar", "claim", "tripod_ai"}
journals = [r for r in published if r["publication_kind"] == "journal" and r["key"] not in excluded]
recent = [r for r in journals if r.get("year", r.get("published", {}).get("date-parts", [[0]])[0][0]) >= 2015]
assert len(recent) >= 30, len(recent)
bib = [r"\begingroup\fontsize{8}{9}\selectfont", r"\begin{thebibliography}{99}",
       r"\setlength{\itemsep}{0pt}\setlength{\parsep}{0pt}\setlength{\parskip}{0pt}\setlength{\baselineskip}{9pt}"]
bib.extend(refs.entry(catalog[k]) if k in catalog else companions[k] for k in keys)
bib += [r"\end{thebibliography}\endgroup"]
bib_text = "\n".join(bib) + "\n"
# Do not imply nonexistent coauthors for a single-author method paper.
bib_text = bib_text.replace("Joshua Goodman et al.", "Joshua Goodman.")
bib_text = bib_text.replace("John Moody et al.", "John Moody and Christian J. Darken.")
bib_text = bib_text.replace("Jerome H. Friedman et al.", "Jerome H. Friedman and Bogdan E. Popescu.")
(C / "references.tex").write_text(bib_text)
inputs = [C / "Histopathology_Architecture_Training_Check.json", V / "Histology_Full_Prediction_Statistics.json",
          C / "CAMELYON_Only_Loss_Correctness.json", W / "review_followup_20261012/Panel_Ensemble_Replay.json"]
inputs += [C / "reproduction/Worked_Evidence_Example.json"]
inputs += [V / f"Completed_Architecture_Statistics/{x}_Statistics.json" for x in S]
record = {"utc": datetime.now(timezone.utc).isoformat(), "passed": True,
          "published_references": len(published), "journal_research_method_references": len(journals),
          "journal_research_method_references_2015_onward": len(recent),
          "unpublished_companions": list(companions), "records": published,
          "application_evidence_scope": "2D CAMELYON17 histopathology only",
          "general_mathematical_dimensions": [2, 3], "3D_application_validation_claim": False,
          "results_input_sha256": {str(x): hashlib.sha256(x.read_bytes()).hexdigest() for x in inputs},
          "trained_table_scope": "Completed classification comparisons; no invented stability or isolated cost columns",
          "global_priority_or_clinical_certification_claim": False}
(C / "Completed_Evidence_Inputs_and_Citations.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({k: v for k, v in record.items() if k not in ("records", "results_input_sha256")}, indent=2))
