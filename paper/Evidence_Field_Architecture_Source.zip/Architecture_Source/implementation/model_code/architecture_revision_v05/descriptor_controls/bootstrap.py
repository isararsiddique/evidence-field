"""Bind authenticated frozen EF source without its training initializer."""
from pathlib import Path
import hashlib
import json
import sys
import types


def bind_frozen_source(application_dir=None):
    application = Path(application_dir) if application_dir else Path(__file__).resolve().parents[2]
    snapshot_path = application / 'source_dependency_snapshot.json'
    snapshot = json.loads(snapshot_path.read_text())
    source = application / 'locked_model_source'
    if len(snapshot['source_hashes']) != 30:
        raise ValueError('Expected the preserved 30-module numerical source contract')
    for relative, digest in snapshot['source_hashes'].items():
        if hashlib.sha256((source / relative).read_bytes()).hexdigest() != digest:
            raise ValueError('Frozen source changed: ' + relative)
    if 'evidence_field' in sys.modules:
        raise RuntimeError('Use a fresh source-control process before binding the frozen package')
    package = types.ModuleType('evidence_field')
    package.__path__ = [str(source / 'evidence_field')]
    sys.modules['evidence_field'] = package
    return dict(application_dir=application, source_dir=source,
                snapshot_sha256=hashlib.sha256(snapshot_path.read_bytes()).hexdigest(),
                numerical_module_count=30)
